﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;


namespace Eragonia_Demo_Day_One
{
    public class ScreenTransistioner
    {
        public Texture2D texture;
        public Color color = new Color(0, 0, 0, 0);
        public Rectangle position = new Rectangle(0, 0, 1280, 960);
        public int timer;
        public Boolean turnBlack = false;
        public Boolean turnWhite = false;
        public Game1 world;
        public Game1.gameState state;
        public void Update()
        {
            if (turnBlack)
            {
                if (color.A <= 250)
                {
                    color.A += 5;
                }
            }
            else if(turnWhite){

                if (color.A >= 5)
                {
                    color.A -= 5;
                }
            }
            else {

            }
        }
        public void Draw(GameTime gameTime, SpriteBatch spriteBatch) {
            spriteBatch.Draw(texture, position, color);
        }
        
    }
}
