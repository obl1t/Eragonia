﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace Eragonia_Demo_Day_One
{
    public class Tile
    {
        public Boolean isPath = false;
        public Boolean isPlaceable = false;
        public Boolean towerPlaced = false;
        public Boolean hasDecoration = false;



        public Texture2D texture;
        public Rectangle position;
        public Rectangle[] sources;
        public Rectangle source;
        public Decoration decoration;
        public int rotation = 0;
        Random rand = new Random();
        public SpriteEffects flip;
        public Color color = Color.White;
        public Tile()
        {
            sources = new Rectangle[3];
            sources[0] = new Rectangle(0, 0, 1028, 1028);
            sources[1] = new Rectangle(1028, 0, 1028, 1028);
            sources[2] = new Rectangle(0, 1028, 1028, 1028);
            flip = SpriteEffects.None;
        }

        public void isBeingHovered(MouseState mouse) {
            if(isPlaceable == false) {
                return;
            }
            if(mouse.X >= position.X - position.Width/2 && mouse.X <= position.X + position.Width/2) {
                if (mouse.Y >= position.Y - position.Height/2 && mouse.Y <= position.Y + position.Height/2)
                {
                    this.color.A = 100;
                    return;
                }
            }
            this.color.A = 255;
        }
        public void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(texture, position, source, color, MathHelper.ToRadians(rotation), new Vector2(source.Width / 2, source.Height / 2), flip, 0.0f);
            if (hasDecoration)
            {

                spriteBatch.Draw(decoration.texture, decoration.position, decoration.source, Color.White, MathHelper.ToRadians(0),
                new Vector2(decoration.source.Width / 2, decoration.source.Height / 2), SpriteEffects.None, 0.0f);
            }
        }
        public void setSource(int a)
        {

            // Console.WriteLine(a);
            if (a < 3)
            {
                source = sources[1];
                hasDecoration = false;
            }
            else if (a < 30)
            {
                source = sources[2];
            }
            else
            {
                source = sources[0];
            }
            if (a % 3 == 0)
            {
                flip = SpriteEffects.FlipHorizontally;
            }
            else if (a % 3 == 1 && a >= 3)
            {
                flip = SpriteEffects.FlipVertically;
            }
            else
            {
                flip = SpriteEffects.None;
            }
        }

    }
}
