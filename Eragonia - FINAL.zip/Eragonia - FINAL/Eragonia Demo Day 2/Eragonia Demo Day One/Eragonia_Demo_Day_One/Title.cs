﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace Eragonia_Demo_Day_One
{
    public class Title
    {
        public Texture2D tex;
        public Rectangle rec;
        public Rectangle pos;
        public Color col;
        public MouseState mouse;
        public Game1 world;

        public Button[] titleButtons;


        public Title(Texture2D t, Rectangle r, Rectangle p, Color c, Button[] b)
        {
            tex = t;
            rec = r;
            pos = p;
            col = c;
            titleButtons = b;
        }

        public void Update()
        {
            for (int i = 0; i < 3; i++)
            {
                titleButtons[i].isOverChoice(mouse.X, mouse.Y, mouse, world.oldM);
                titleButtons[i].whatButton();
                if (titleButtons[0].bp == Button.buttonPress.pressed)
                {
                    world.transistioner.state = Game1.gameState.Artifacts;
                    world.transistioner.turnBlack = true;
                    world.transistion = Game1.transistionState.Transistioning;


                }
                if (titleButtons[1].bp == Button.buttonPress.pressed)
                {
                    world.gS = Game1.gameState.Options;
                }
                if (titleButtons[2].bp == Button.buttonPress.pressed)
                {
                    world.gS = Game1.gameState.QuitGame;
                }
            }
        }


        public void Draw(GameTime gameTime, SpriteBatch sb)
        { 
            // TODO: Add your drawing code here
            sb.Draw(tex, rec, pos, col);
            for (int i = 0; i < 3; i++)
            {
                titleButtons[i].Draw(gameTime, sb);
            }
        }
    }
}
