﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
namespace Eragonia_Demo_Day_One
{
    class SelectionBar
    {
        public Texture2D texture;
        public Rectangle position;
        public List<Texture2D> attackTowerTextures = new List<Texture2D>();
        public List<Texture2D> resourceTowerTextures = new List<Texture2D>();
        public MouseState oldMouse = Mouse.GetState();
        public enum ViewType { attack, resource, tierUp };
        public ViewType viewType = ViewType.attack;
        public Texture2D dummyTexture;
        public Texture2D infoTexture;
        public SpriteFont font;
        public Rectangle dummyPos;
        public Boolean drawSelection = false;
        public ResourceBar resources;
        public Game1 world;
        public BarButtons buttons;
        public Infobox box = new Infobox();
        public String[] infoTexts = new String[15];



        public void Initialize()
        {
            buttons = new BarButtons();
            for (int i = 0; i < 15; i++)
            {
                infoTexts[i] = " ";
            }
            box.texture = infoTexture;
            box.font = font;
            box.position = new Rectangle(-250, 500, 250, 300);
            infoTexts[0] = "\n75 GOLD \n40 STONE \n\n\n\n\nThe clubber\nlikes smashing \nthings. \nBhaykerr's \nminions are \nno exception.\n\nDamage: 20\nRange: 100\nAverage Speed\nMild AOE";
            infoTexts[1] = "\n80 GOLD \n40 STONE \n\n\n\n\nShoots enemies \nwith deadly \naccuracy. For \na caveman, \nthat is. \n\n\nDamage: 30\nRange: 350\nSlow Speed\nSingle-target";
            infoTexts[2] = "\n125 GOLD \n40 STONE \n\n\nWhen asked \nwhere he \ngot the \nendless supply \nof knives\nfrom, the\nknifer replied \n\"Ooga Booga\" \n\nDamage: 10\nRange: 210\nFast Speed\nSingle-target";
            infoTexts[3] = "\n100 GOLD \n50 STONE \n\n\n\n\nChannels fire \nto burn \nenemies into \na pile\nof ash.\n\nDamage: 15\nRange: 100\nAverage Speed\nMild DOT";
            infoTexts[10] = "\n75 GOLD \n30 STONE \n\n\n\n\nDigs up \npebbles below\nthe surface\nof the\nplentiful \nvalley. \n\nCollection: \n1 Stone\nper second";
            box.isInitialized = true;
        }
        public void isClicking(MouseState mouse, KeyboardState kb)
        {
            if (mouse.X > 350 && mouse.Y > position.Y + 40 && mouse.X < 1240)
            {
                int index = (mouse.X - 350) / 128;
                if (index < 4)
                {
                    box.text = infoTexts[index];
                    box.position.X = ((mouse.X - 350) / 128) * 128 + 275;
                }
                else {
                    box.position.X = -250;
                }
                if(viewType == ViewType.resource) {
                    if (index < 1)
                    {
                        box.text = infoTexts[(mouse.X - 350) / 128 + 10];
                        box.position.X = ((mouse.X - 350) / 128) * 128 + 275;
                    }
                    
                    else {
                        box.position.X = -250;
                    }
                }
                
                drawSelection = true;
                dummyPos = new Rectangle(((mouse.X - 350) / 128) * 128 + 350, position.Y + 40, 128, 128);
                if (mouse.LeftButton == ButtonState.Pressed && oldMouse.LeftButton != ButtonState.Pressed)
                {
                    if (viewType == ViewType.attack)
                    {
                        spawnAttackSelector((mouse.X - 350) / 128);
                    }
                    if (viewType == ViewType.resource)
                    {
                        spawnResourceSelector((mouse.X - 350) / 128);
                    }
                }




            }
            else
            {
                drawSelection = false;


            }
            if (kb.IsKeyDown(Keys.D1) || kb.IsKeyDown(Keys.NumPad1))
            {
                viewType = ViewType.attack;
                buttons.current = BarButtons.Selected.Attack;
            }
            if (kb.IsKeyDown(Keys.D2) || kb.IsKeyDown(Keys.NumPad2))
            {
                viewType = ViewType.resource;
                buttons.current = BarButtons.Selected.Resource;
            }
            buttons.isClicking(mouse);
            viewType = (ViewType)(int)buttons.current;
            oldMouse = mouse;
        }

        public void spawnAttackSelector(int index)
        {

            world.LoadSpawner(index);

        }

        public void spawnResourceSelector(int index)
        {

            world.LoadResourceSpawner(index);

        }
        public void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(texture, position, Color.White);
            if (viewType == ViewType.attack)
            {

                for (int i = 0; i < attackTowerTextures.Count; i++)
                {

                    spriteBatch.Draw(attackTowerTextures[i], new Rectangle(350 + i * 128, position.Y + 40, 128, 140), Color.White);

                }

            }
            if (viewType == ViewType.resource)
            {

                for (int i = 0; i < resourceTowerTextures.Count; i++)
                {

                    spriteBatch.Draw(resourceTowerTextures[i], new Rectangle(350 + i * 128, position.Y + 40, 128, 140), Color.White);

                }
                

            }
            buttons.Draw(gameTime, spriteBatch);
            if (drawSelection)
            {
                spriteBatch.Draw(dummyTexture, dummyPos, new Color(255, 255, 255, 120));
                box.Draw(gameTime, spriteBatch);
            }
        }
    }
}
