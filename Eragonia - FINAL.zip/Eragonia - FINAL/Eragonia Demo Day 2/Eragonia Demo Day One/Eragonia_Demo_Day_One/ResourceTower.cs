﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.IO;


namespace Eragonia_Demo_Day_One
{
    class ResourceTower
    {
        public Texture2D texture;
        public Rectangle position;
        public List<Rectangle> sources = new List<Rectangle>();
        public List<int> animationOrder = new List<int>();
        public int resourceType;
        public int resourceAmount;
        public ResourceBar bar;
        public int multiplier;
        public int fps = 5;
        public Boolean isFirstTower;
        public int currentIndex = 0;
        public Game1 world;
        int timer = 0;

        public void Update()
        {
            if (timer % fps == 0)
            {
                currentIndex++;
            }

            if (currentIndex >= animationOrder.Count)
            {
                currentIndex = 0;
            }
            
            timer++;

        }
        public void UpdateResources() {
            if (isFirstTower)
            {
                if (timer % 60 == 0)
                {

                    bar.updateResources(resourceType, resourceAmount / 2);
                }
            }
            else {
                if(timer % 120 == 0) {
                    bar.updateResources(resourceType, resourceAmount / 2);
                }
            }
        }
        public void addAnimationOrder(int[] order)
        {
            for (int i = 0; i < order.Length; i++)
            {
                animationOrder.Add(order[i] - 1);
            }
        }
        public void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(texture, new Rectangle(position.X + 3, position.Y + 3, position.Width, position.Height), sources[animationOrder[currentIndex]], new Color(0, 0, 0, 120));
            spriteBatch.Draw(texture, position, sources[animationOrder[currentIndex]], Color.White);
        }
    }
}
