﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.IO;


namespace Eragonia_Demo_Day_One
{
    class TowerSelector
    {
        public Texture2D texture;
        public Game1 world;
        public int towerType;
        int mouseX;
        int mouseY;
        MouseState oldMouse = Mouse.GetState();
        public void Update(MouseState mouse)
        {
            mouseX = mouse.X/64 * 64;
            mouseY = mouse.Y/64 * 64;
            if(mouse.LeftButton == ButtonState.Pressed && oldMouse.LeftButton != ButtonState.Pressed)
            {
                world.placeTower(towerType, mouseX, mouseY);
            }
            oldMouse = mouse;
        }
        public void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(texture, new Rectangle(mouseX, mouseY + 6, 64, 70), Color.White);

        }
    }
}
