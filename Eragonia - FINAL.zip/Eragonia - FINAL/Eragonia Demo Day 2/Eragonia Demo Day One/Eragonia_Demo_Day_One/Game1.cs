using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.IO;

namespace Eragonia_Demo_Day_One
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        //Mikey

        public enum gameState { TitleScreen, Artifacts, PlayGame, Pause, Options, QuitGame, ReallyQuit, LostGame, WinGame }
        public enum transistionState { Default, Transistioning} ;
        public gameState gS;
        public transistionState transistion;
        public MouseState oldM;
        Rectangle[] buttonSprites;

        int time;

        Background bG;

        TipsAndTricks titleTips;

        public Title titleObj;
        Options optObj;
        List<Button> optButton;
        Quit quitObj;
        List<Button> quitButtons;
        List<Button> artifactButtons = new List<Button>();
        public List<EnemySuper> totalEnemies = new List<EnemySuper>();
        public List<EnemySuper> enemies = new List<EnemySuper>();
        public List<EnemySuper> activeEnemies = new List<EnemySuper>();
       
        WaveLoader levelLoad = new WaveLoader();
        

        Loss losCond;

        public int breachedEnemiesAllowed = 0;
        public Boolean lawnMowerAvaliable = false;

        //Vivek
        SelectionBar mainBar;
        KeyboardState kb;
        Rectangle artifactRectangle;
        public int currentWave = 1;
        public Texture2D dummyTexture;
        public Tile[,] tileMap;
        Decoration[,] decoMap;
        Random rand = new Random();
        public ResourceBar bar;
        public Boolean canShowRange = true;
        ResourceTower temp2;
        Texture2D[] tempTextures;
        List<AttackSuper> attackTowers = new List<AttackSuper>();
        List<ResourceTower> resourceTowers = new List<ResourceTower>();
        List<ArtifactItem> artifacts = new List<ArtifactItem>();
        TowerSelector spawner;
        SpriteFont font;
        WaveButton waveButton = new WaveButton();
        public ScreenTransistioner transistioner = new ScreenTransistioner();
        Texture2D artifactTexture;
        Texture2D artifactTitle;
        Rectangle artTitlePos;
        public int prestige = 1500;
        Vector2 prestigePos;
        public double damageMultiplier = 1;
        public Boolean applyCrowbar = false;
        int enemyTimer;
        public int towerID = 0;
        public int shownRangeID = -1;
        public int prestigeMult = 1;
        public Boolean shouldRefundUpgrade = false;
        public Boolean upgrade1Unlocked = false;
        public Boolean upgrade2Unlocked = false;
        public double healthDivider = 1;
        public Boolean[] hasPlacedResourceTower = new Boolean[4];
        public Infobox shownInfoBox;
        public UpgradeButton shownUpgrade;
       
        //Paulo
        Texture2D[] bGt;
        Background cloud;
        Background bGcloud;
        Background birds;
        int bGtime;


        PauseInfoBox pauseinfobox;
        int cdTime;
        bool cooldown;
        List<PauseButton> pauseButton;


        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            //Mikey

            oldM = Mouse.GetState();

            gS = gameState.TitleScreen;
            buttonSprites = new Rectangle[] { new Rectangle(0, 0, 1000, 400), new Rectangle(1024, 0, 1000, 400), new Rectangle(0, 400, 1000, 400), new Rectangle(1024, 400, 1000, 400) };

            graphics.PreferredBackBufferHeight = 960;
            graphics.PreferredBackBufferWidth = 1280;
            graphics.ApplyChanges();

            time = 360;
            levelLoad.world = this;

            //Vivek

            tileMap = new Tile[15, 20];
            decoMap = new Decoration[15, 20];
            for(int i = 0; i < 4; i++) {
                hasPlacedResourceTower[i] = false;
            }
            // GraphicsDevice.BlendState = BlendState.Additive;

            tempTextures = new Texture2D[5];
            artifactRectangle = new Rectangle(0, 0, 1280, 960);

            //Pau pau
            bGt = new Texture2D[8];
            bGtime = 0;

            cooldown = false;
            cdTime = 0;


            // this.Window.AllowUserResizing = true;

            IsMouseVisible = true;

            base.Initialize();
        }

        public void LoadSpawner(int index)
        {
            if (index == 0)
            {
                spawner = new TowerSelector();
                spawner.texture = this.Content.Load<Texture2D>("GUI/Thumbnails/clubberThumb");
                spawner.world = this;
                spawner.towerType = 0;
                spawner.Update(Mouse.GetState());
            }
            if (index == 1)
            {
                spawner = new TowerSelector();
                spawner.texture = this.Content.Load<Texture2D>("GUI/Thumbnails/bowerThumb");
                spawner.world = this;
                spawner.towerType = 1;
                spawner.Update(Mouse.GetState());
            }
            if (index == 2)
            {
                spawner = new TowerSelector();
                spawner.texture = this.Content.Load<Texture2D>("GUI/Thumbnails/knifeThumb");
                spawner.world = this;
                spawner.towerType = 2;
                spawner.Update(Mouse.GetState());
            }
            if (index == 3)
            {
                spawner = new TowerSelector();
                spawner.texture = this.Content.Load<Texture2D>("GUI/Thumbnails/torcherThumb");
                spawner.world = this;
                spawner.towerType = 3;
                spawner.Update(Mouse.GetState());
            }
            
        }
        public void LoadResourceSpawner(int index) {
            if(index == 0) {
                spawner = new TowerSelector();
                spawner.texture = this.Content.Load<Texture2D>("GUI/Thumbnails/stonerThumb");
                spawner.world = this;
                spawner.towerType = 10;
                spawner.Update(Mouse.GetState());
            }
        }
        public void RemoveSpawner()
        {
            spawner = null;
        }

        public void placeTower(int index, int mouseX, int mouseY)
        {
            Tile t = getTile(mouseX, mouseY);
            if (t.isPlaceable && !t.towerPlaced)
            {
               
                
                int i = mouseX / 64;
                int j = mouseY / 64;
                if(index == 0) {
                    if (bar.resources[0] >= 75 && bar.resources[1] >= 40)
                    {
                        t.towerPlaced = true;
                        bar.resources[0] -= 75;
                        bar.resources[1] -= 40;
                        loadClubber(new Rectangle(i * 64 + 32, j * 64 + 32, 64, 70));
                        t.hasDecoration = false;
                    }
                }
                if (index == 1)
                {
                    if (bar.resources[0] >= 80 && bar.resources[1] >= 40)
                    {
                        t.towerPlaced = true;
                        bar.resources[0] -= 80;
                        bar.resources[1] -= 40;
                        loadBower(new Rectangle(i * 64 + 32, j * 64 + 32, 64, 70));
                        t.hasDecoration = false;
                    }
                }
                if (index == 2)
                {
                    if (bar.resources[0] >= 125 && bar.resources[1] >= 40)
                    {
                        t.towerPlaced = true;
                        bar.resources[0] -= 125;
                        bar.resources[1] -= 40;
                        loadKnifer(new Rectangle(i * 64 + 32, j * 64 + 32, 64, 70));
                        t.hasDecoration = false;
                    }
                }
                if (index == 3)
                {
                    if (bar.resources[0] >= 100 && bar.resources[1] >= 50)
                    {
                        t.towerPlaced = true;
                        bar.resources[0] -= 100;
                        bar.resources[1] -= 50;
                        loadTorcher(new Rectangle(i * 64 + 32, j * 64 + 32, 64, 70));
                        t.hasDecoration = false;
                    }
                }
                if(index == 10)
                {
                    if (bar.resources[0] >= 75 && bar.resources[1] >= 30)
                    {
                        t.towerPlaced = true;
                        bar.resources[0] -= 75;
                        bar.resources[1] -= 30;
                        loadStoner(new Rectangle(i * 64, j * 64 + 6, 64, 70));
                        t.hasDecoration = false;
                    }
                }
                

            }
            spawner = null;
        }
        
        public Tile getTile(int mouseX, int mouseY)
        {
            int i = mouseX / 64;
            int j = mouseY / 64;
            
            if( i < tileMap.GetLength(1) && j < tileMap.GetLength(0)) {
                
                return tileMap[j, i];
            }
            Tile temp = new Tile();
            temp.isPlaceable = false;
            return temp;
        }
        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            //Mikey
            dummyTexture = new Texture2D(GraphicsDevice, 1, 1);
            dummyTexture.SetData(new Color[] { Color.White });

            titleTips = new TipsAndTricks(Color.White, this.Content.Load<SpriteFont>("TitleScreen/Tips/Font/TipsFont"));
            loadText(@"Content/TitleScreen/Tips/greatAdvice.txt");
            titleTips.changeTip();

            bG = new Background(this.Content.Load<Texture2D>("TitleScreen/Background/background2"), new Rectangle(0, 0, graphics.GraphicsDevice.Viewport.Width, graphics.GraphicsDevice.Viewport.Height), new Rectangle(0, 0, 1960, 1470), Color.White);

            Button[] tB = new Button[3];
            for (int i = 0; i < 3; i++)
            {
                tB[i] = new Button(this.Content.Load<Texture2D>("TitleScreen/Buttons/ButtonsTry"), new Rectangle(480, 320 + (i * 150), 320, 100), buttonSprites, Color.White, this.Content.Load<SpriteFont>("TitleScreen/Buttons/Font/ButtonFont"), true);
            }

            titleObj = new Title(this.Content.Load<Texture2D>("TitleScreen/Title/TitleImage"), new Rectangle(290, 20, 800, 300), new Rectangle(0, 0, 2048, 782), Color.White, tB);
            titleObj.titleButtons[0].text = "Start";
            titleObj.titleButtons[1].text = "Options";
            titleObj.titleButtons[2].text = "Quit";
            titleObj.titleButtons[0].painNum = 345;
            titleObj.titleButtons[1].painNum = 225;
            titleObj.titleButtons[2].painNum = 405;

            Button[] qB = new Button[2];
            for (int i = 0; i < 2; i++)
            {
                qB[i] = new Button(this.Content.Load<Texture2D>("TitleScreen/Buttons/ButtonsTry"), new Rectangle(300 + (i * 400), 500, 320, 100), buttonSprites, Color.White, this.Content.Load<SpriteFont>("TitleScreen/Buttons/Font/ButtonFont"), true);
            }
            quitObj = new Quit(this.Content.Load<Texture2D>("TitleScreen/Quit/AYSYWTQ"), new Rectangle(150, 200, 960, 540), new Rectangle(0, 0, 960, 540), Color.White, qB);
            quitObj.quitButtons[0].text = "Quit";
            quitObj.quitButtons[1].text = "Cancel";
            quitObj.quitButtons[0].painNum = 223;
            quitObj.quitButtons[1].painNum = 510;

            Button[] oB = new Button[2];
            for (int i = 0; i < 2; i++)
            {
                oB[i] = new Button(this.Content.Load<Texture2D>("TitleScreen/Buttons/ButtonsTry"), new Rectangle(300 + (i * 400), 750, 320, 100), buttonSprites, Color.White, this.Content.Load<SpriteFont>("TitleScreen/Buttons/Font/ButtonFont"), true);
            }
            optObj = new Options(this.Content.Load<Texture2D>("TitleScreen/Options/Keyboard"), new Rectangle(150, 200, 936, 501), new Rectangle(0, 0, 624, 334), Color.White, oB);
            optObj.optButtons[0].text = "Config";
            optObj.optButtons[0].painNum = 100;
            optObj.optButtons[1].text = "Return";
            optObj.optButtons[1].painNum = 500;

            levelLoad.loadEnemies(@"Content/Levels/Levels.txt", totalEnemies);

            for (int i = 0; i < totalEnemies.Count; i++)
            {
                totalEnemies[i].healthSprite = this.Content.Load<Texture2D>("Enemy/EnemyHealthBar");
                totalEnemies[i].healthBar = new Rectangle(totalEnemies[i].position.X, totalEnemies[i].position.Y, totalEnemies[i].position.Width, 10);
                totalEnemies[i].dummyTexture = dummyTexture;
                totalEnemies[i].calculateOrigin();
            }

            losCond = new Loss(oldM, this.Content.Load<SpriteFont>("TitleScreen/Buttons/Font/ButtonFont"), new Button[] { new Button(this.Content.Load<Texture2D>("TitleScreen/Buttons/ButtonsTry"), new Rectangle(200, 800, 320, 100), 
            buttonSprites, Color.White, this.Content.Load<SpriteFont>("TitleScreen/Buttons/Font/ButtonFont"), true), 
            new Button(this.Content.Load<Texture2D>("TitleScreen/Buttons/ButtonsTry"), new Rectangle(770, 800, 320, 100), buttonSprites, 
            Color.White, this.Content.Load<SpriteFont>("TitleScreen/Buttons/Font/ButtonFont"), true) });
            losCond.lossButtons[0].text = "Retry";
            losCond.lossButtons[0].painNum = 62;
            losCond.lossButtons[1].text = "Quit";
            losCond.lossButtons[1].painNum = 695;


            //Vivek
            font = this.Content.Load<SpriteFont>("TitleScreen/Buttons/Font/ButtonFont");

           
            mainBar = new SelectionBar();
            mainBar.texture = this.Content.Load<Texture2D>("GUI/main_bar");
            mainBar.position = new Rectangle(256, 796, 1200, 164);
            mainBar.world = this;
            mainBar.resources = bar;
            mainBar.attackTowerTextures.Add(this.Content.Load<Texture2D>("GUI/Thumbnails/clubberThumb"));
            mainBar.attackTowerTextures.Add(this.Content.Load<Texture2D>("GUI/Thumbnails/bowerThumb"));
            mainBar.attackTowerTextures.Add(this.Content.Load<Texture2D>("GUI/Thumbnails/knifeThumb"));
            mainBar.attackTowerTextures.Add(this.Content.Load<Texture2D>("GUI/Thumbnails/torcherThumb"));
            mainBar.resourceTowerTextures.Add(this.Content.Load<Texture2D>("GUI/Thumbnails/stonerThumb"));
            mainBar.dummyTexture = dummyTexture;
            mainBar.infoTexture = this.Content.Load<Texture2D>("GUI/infobox");
            mainBar.font = this.Content.Load<SpriteFont>("Other/Font2");
            mainBar.Initialize();
            mainBar.buttons.texture = this.Content.Load<Texture2D>("GUI/barButtons");
            mainBar.buttons.position = new Rectangle(700, 796, 140, 26);
            tempTextures[1] = this.Content.Load<Texture2D>("GUI/pause");
            tempTextures[2] = this.Content.Load<Texture2D>("GUI/fast");
           
            waveButton.position = new Rectangle(1092, 0, 188, 128);
            waveButton.texture = this.Content.Load<Texture2D>("GUI/waveButton");

            transistioner.texture = dummyTexture;


            artifactTexture = this.Content.Load<Texture2D>("GUI/artifact");
            tempTextures[4] = this.Content.Load<Texture2D>("Towers/torcher");
            bar = new ResourceBar(this.Content.Load<SpriteFont>("Other/Font1"));
            bar.texture = this.Content.Load<Texture2D>("GUI/resource_bar");
            bar.position = new Rectangle(0, 690, 192, 270);
            bar.updateResources(0, 200);
            bar.updateResources(1, 80);
            mainBar.resources = bar;
            loadTiles(@"Content/Other/map.txt");
            loadDecos(@"Content/Other/decorations.txt");


            artifactButtons.Add(new Button(this.Content.Load<Texture2D>("TitleScreen/Buttons/ButtonsTry"), new Rectangle(480, 760, 320, 100), buttonSprites, Color.White, this.Content.Load<SpriteFont>("TitleScreen/Buttons/Font/ButtonFont"), true));
            artifactButtons[0].text = "BEGIN";
            artifactButtons[0].painNum = 345;


            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 2; j++)
                {
                    loadArtifactItem(new Rectangle(i * 350 + 168, j * 200 + 300, 244, 168), i + j*3);
                }
            }
            artifactTitle = this.Content.Load<Texture2D>("GUI/artifactTitle");
            artTitlePos = new Rectangle(80, -30, 1120, 240);
            Vector2 temp = font.MeasureString("Your Prestige: 1500");
            prestigePos = new Vector2(640 - temp.X / 2, 200);

            //paulo
            for (int i = 0; i < 8; i++)
            {
                bGt[i] = this.Content.Load<Texture2D>("TitleScreen/Background/bg" + i);
            }
            birds = new Background(this.Content.Load<Texture2D>("TitleScreen/Background/bird boiz"), new Rectangle(0, 0, graphics.GraphicsDevice.Viewport.Width, graphics.GraphicsDevice.Viewport.Height), new Rectangle(0, 0, 1960, 1470), Color.White);
            bG = new Background(bGt[0], new Rectangle(0, 0, graphics.GraphicsDevice.Viewport.Width, graphics.GraphicsDevice.Viewport.Height), new Rectangle(0, 0, 1960, 1470), Color.White);
            cloud = new Background(this.Content.Load<Texture2D>("TitleScreen/Background/cloudy boi v2"), new Rectangle(bG.rec.Width, 0, graphics.GraphicsDevice.Viewport.Width, graphics.GraphicsDevice.Viewport.Height), new Rectangle(0, 0, 1960, 1470), Color.White);
            bGcloud = new Background(this.Content.Load<Texture2D>("TitleScreen/Background/cloudy boi v2"), new Rectangle(0, 0, graphics.GraphicsDevice.Viewport.Width, graphics.GraphicsDevice.Viewport.Height), new Rectangle(0, 0, 1960, 1470), Color.White);

            pauseButton = new List<PauseButton>();
            for (int i = 0; i < 2; i++)
            {
                pauseButton.Add(new PauseButton(this.Content.Load<Texture2D>("GUI/pause"), new Rectangle(24, 24, 64, 64), Color.White));
            }
            pauseinfobox = new PauseInfoBox(this.Content.Load<Texture2D>("GUI/pause info box"), new Rectangle(240, 240, 800, 300), "GAME PAUSED", this.Content.Load<SpriteFont>("TitleScreen/Buttons/Font/ButtonFont"));
            pauseinfobox.painNum = -10;


            // TODO: use this.Content to load your game content here
        }

        public void loadEnemy()
        {
            activeEnemies.Add(enemies[0]);
            enemies[0].calculateOrigin();
            enemies.Remove(enemies[0]);  
        }
        public void loadTorcher(Rectangle pos)
        {

            Torcher temp = new Torcher();
            temp.spriteSheet = this.Content.Load<Texture2D>("Towers/torcher");
            temp.position = pos;
            temp.calculateOrigin();
            temp.addRange(this.Content.Load<Texture2D>("Towers/GUI/range"), 96);
            temp.world = this;
            temp.shockTex = this.Content.Load<Texture2D>("Towers/GUI/shockwave");
            temp.id = towerID;
            towerID++;
            temp.infoTex = this.Content.Load<Texture2D>("GUI/infobox2");
            temp.font = this.Content.Load<SpriteFont>("Other/Font2");
            temp.upgradeTexture = this.Content.Load<Texture2D>("GUI/upgradeButton");
            temp.setUpgrade();
            attackTowers.Add(temp);
        }
        public void loadBower(Rectangle pos)
        {

            Bower temp = new Bower();
            temp.spriteSheet = this.Content.Load<Texture2D>("Towers/bower");
            temp.position = pos;
            temp.calculateOrigin();
            temp.addRange(this.Content.Load<Texture2D>("Towers/GUI/range"), 350);
            temp.world = this;
            temp.projectileTex = this.Content.Load<Texture2D>("Towers/GUI/arrow");
            temp.id = towerID;
            towerID++;
            temp.infoTex = this.Content.Load<Texture2D>("GUI/infobox2");
            temp.font = this.Content.Load<SpriteFont>("Other/Font2");
            temp.upgradeTexture = this.Content.Load<Texture2D>("GUI/upgradeButton");
            temp.setUpgrade();
            attackTowers.Add(temp);
        }

        public void loadClubber(Rectangle pos)
        {
            Clubber temp = new Clubber();
            temp.spriteSheet = this.Content.Load<Texture2D>("Towers/clubber");
            temp.position = pos;
            temp.calculateOrigin();
            temp.addRange(this.Content.Load<Texture2D>("Towers/GUI/range"), 96);
            temp.world = this;
            temp.shockTex = this.Content.Load<Texture2D>("Towers/GUI/shockwave");
            temp.id = towerID;
            towerID++;
            temp.infoTex = this.Content.Load<Texture2D>("GUI/infobox2");
            temp.font = this.Content.Load<SpriteFont>("Other/Font2");
            temp.upgradeTexture = this.Content.Load<Texture2D>("GUI/upgradeButton");
            temp.setUpgrade();
            attackTowers.Add(temp);
        }

        public void loadKnifer(Rectangle pos)
        {
            KnifeThrower temp = new KnifeThrower();
            temp.spriteSheet = this.Content.Load<Texture2D>("Towers/knifer");
            temp.position = pos;
            temp.calculateOrigin();
            temp.addRange(this.Content.Load<Texture2D>("Towers/GUI/range"), 210);
            temp.world = this;
            temp.projectileTex = this.Content.Load<Texture2D>("Towers/GUI/knife");
            temp.id = towerID;
            towerID++;
            temp.infoTex = this.Content.Load<Texture2D>("GUI/infobox2");
            temp.font = this.Content.Load<SpriteFont>("Other/Font2");
            temp.upgradeTexture = this.Content.Load<Texture2D>("GUI/upgradeButton");
            temp.setUpgrade();
            attackTowers.Add(temp);
        }

        public void loadStoner(Rectangle pos)
        {
            temp2 = new ResourceTower();
            temp2.addAnimationOrder(new int[] { 1, 1, 1, 1, 1, 1, 1, 2, 3, 3, 3, 3, 4, 4, 3, 3, 4, 4, 3, 3, 4, 4, 3, 3, 3, 3, 3, 2, 2, 1, 1 });
            temp2.texture = this.Content.Load<Texture2D>("Towers/digger");
            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 2; j++)
                {
                    temp2.sources.Add(new Rectangle(j * 832, i * 910, 832, 910));
                }
            }
            temp2.bar = bar;
            temp2.world = this;
            if(!hasPlacedResourceTower[0]) {
                hasPlacedResourceTower[0] = true;
                temp2.isFirstTower = true;
            }
            else {
                temp2.isFirstTower = false;
            }
            temp2.position = pos;
            temp2.resourceAmount = 2;
            temp2.resourceType = 1;


            resourceTowers.Add(temp2);
        }

        public void loadArtifactItem(Rectangle pos, int index)
        {
            ArtifactItem temp = new ArtifactItem();
            temp.texture = artifactTexture;
            temp.position = pos;
            temp.artifactID = index;
            temp.world = this;
            temp.font = this.Content.Load<SpriteFont>("Other/Font2");
            String[] texts = new String[3];
            if (index == 0)
            {
                texts[0] = "Increase tower damage.";
                texts[1] = "Further increase tower damage.";
                texts[2] = "The first attack on an enemy deals extra damage.";
                temp.prestigeCosts[0] = 50;
                temp.prestigeCosts[1] = 250;
                temp.prestigeCosts[2] = 1000;
            }
            else if(index == 1) 
            {
                texts[0] = "Unlock level 1 tower upgrades.";
                texts[1] = "Unlock level 2 tower upgrades.";
                texts[2] = "Upgrade costs are partially refunded upon tiering up.";
                temp.prestigeCosts[0] = 50;
                temp.prestigeCosts[1] = 250;
                temp.prestigeCosts[2] = 1000;
            }
            else if(index == 2)
            {
                texts[0] = "Starting health of enemies decreases";
                texts[1] = "Starting health of enemies further decreases";
                texts[2] = "Starting health of enemies is at 90%";
                temp.prestigeCosts[0] = 50;
                temp.prestigeCosts[1] = 250;
                temp.prestigeCosts[2] = 1000;
            }
            else if (index == 3)
            {
                texts[0] = "Allows one extra enemy to breach the gates";
                texts[1] = "Allows two extra enemies to breach the gates";
                texts[2] = "When an enemy reaches the gates, every enemy on the field dies (One use)";
                temp.prestigeCosts[0] = 50;
                temp.prestigeCosts[1] = 250;
                temp.prestigeCosts[2] = 1000;
            }
            else
            {
                texts[0] = "placeholder";
                texts[1] = "placeholder";
                texts[2] = "placeholder";
                temp.prestigeCosts[0] = 0;
                temp.prestigeCosts[1] = 0;
                temp.prestigeCosts[2] = 0;
            }
            temp.barTexture = dummyTexture;
            temp.setTexts(texts);
            temp.setSources();
            artifacts.Add(temp);
        }

        public void loadTiles(String fileName)
        {
            using (StreamReader reader = new StreamReader(fileName))
            {
                try
                {
                    int i = 0;
                    while (!reader.EndOfStream)
                    {

                        String s = reader.ReadLine();
                        Char[] chars = s.ToCharArray();

                        for (int j = 0; j < chars.Length; j++)
                        {

                            Tile temp = new Tile();
                            if (chars[j] == 'g')
                            {

                                temp.color = Color.White;
                                temp.isPath = false;
                                temp.isPlaceable = true;
                                temp.texture = this.Content.Load<Texture2D>("Tiles/grass");
                                int a = rand.Next(0, 100);
                                temp.setSource(a);
                            }
                            else if (chars[j] == 'p')
                            {
                                temp.color = Color.White;
                                temp.isPath = true;
                                temp.texture = this.Content.Load<Texture2D>("Tiles/path");
                                int a = rand.Next(5, 100);
                                temp.setSource(a);
                            }
                            else if (chars[j] == 'v')
                            {
                                temp.color = Color.White;
                                temp.isPath = true;
                                temp.texture = this.Content.Load<Texture2D>("Tiles/path");
                                int a = rand.Next(5, 100);
                                temp.setSource(a);
                                temp.rotation = 270;
                            }
                            else if (chars[j] == '1')
                            {
                                temp.color = Color.White;
                                temp.isPath = true;
                                temp.texture = this.Content.Load<Texture2D>("Tiles/corner");
                                temp.source = new Rectangle(0, 0, 1024, 1024);
                                temp.rotation = 0;

                            }
                            else if (chars[j] == '2')
                            {
                                temp.color = Color.White;
                                temp.isPath = true;
                                temp.texture = this.Content.Load<Texture2D>("Tiles/corner");
                                temp.source = new Rectangle(0, 0, 1024, 1024);
                                temp.rotation = 90;
                                //temp.flip = SpriteEffects.FlipHorizontally;

                            }
                            else if (chars[j] == '3')
                            {
                                temp.color = Color.White;
                                temp.isPath = true;
                                temp.texture = this.Content.Load<Texture2D>("Tiles/corner");
                                temp.source = new Rectangle(0, 0, 1024, 1024);
                                temp.rotation = 270;

                            }
                            else if (chars[j] == '4')
                            {
                                temp.color = Color.White;
                                temp.isPath = true;
                                temp.texture = this.Content.Load<Texture2D>("Tiles/corner");
                                temp.source = new Rectangle(0, 0, 1024, 1024);
                                temp.rotation = 180;
                                //temp.flip = SpriteEffects.FlipHorizontally;

                            }
                            else if (chars[j] == 'w')
                            {
                                temp.color = Color.White;
                                temp.isPath = false;
                                temp.texture = this.Content.Load<Texture2D>("Tiles/water");
                                temp.source = new Rectangle(0, 0, 1024, 1024);
                                temp.rotation = 0;
                            }
                            else if (chars[j] == 't')
                            {
                                temp.color = Color.White;
                                temp.isPath = false;
                                temp.texture = this.Content.Load<Texture2D>("Tiles/water_top");
                                temp.source = new Rectangle(0, 0, 1024, 1024);
                                temp.rotation = 0;
                            }
                            temp.position = new Rectangle(j * 64 + 32, i * 64 + 32, 64, 64);


                            tileMap[i, j] = temp;
                        }
                        i++;

                    }


                }
                catch
                {

                }
            }
        }

        public void loadDecos(String fileName)
        {
            using (StreamReader reader = new StreamReader(fileName))
            {
                try
                {
                    int i = 0;
                    while (!reader.EndOfStream)
                    {

                        String s = reader.ReadLine();
                        Char[] chars = s.ToCharArray();

                        for (int j = 0; j < chars.Length; j++)
                        {

                            Decoration temp = new Decoration();
                            if (chars[j] == 'l')
                            {
                                temp.source = new Rectangle(0, 0, 512, 512);
                            }
                            else if (chars[j] == 't')
                            {
                                temp.source = new Rectangle(512, 0, 512, 512);
                            }
                            else if (chars[j] == 's')
                            {
                                temp.source = new Rectangle(0, 512, 512, 512);
                            }
                            if (chars[j] != '.')
                            {
                                tileMap[i, j].hasDecoration = true;
                                tileMap[i, j].decoration = temp;
                            }
                            temp.position = new Rectangle(j * 64 + 32, i * 64 + 32, 64, 64);
                            temp.texture = this.Content.Load<Texture2D>("Tiles/decorations");

                            decoMap[i, j] = temp;
                        }
                        i++;

                    }


                }
                catch
                {
                    Console.WriteLine("ERROR");
                }
            }
        }


        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        /// 

        public void loadText(string path)
        {
            try
            {
                using (StreamReader reader = new StreamReader(path))
                {
                    while(!reader.EndOfStream){
                        string line = reader.ReadLine();
                        titleTips.text.Add(line);
                        
                    }
                    
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Hey it broke fix -->" + e);
            }
        }

        public void retry()
        {
            gS = gameState.TitleScreen;

            //Vivek
            
            loadTiles(@"Content/Other/map.txt");
            loadDecos(@"Content/Other/decorations.txt");
            levelLoad.loadEnemies(@"Content/Levels/Levels.txt", totalEnemies);
            currentWave = 1;
            bar.resources[0] = 200;
            bar.resources[1] = 80;
            waveButton.current = WaveButton.Selected.Default;
            
            for (int i = activeEnemies.Count - 1; i >= 0; i--)
            {
                activeEnemies.RemoveAt(i);
            }
            for (int i = resourceTowers.Count - 1; i >= 0; i--)
            {
                resourceTowers.RemoveAt(i);
            }
            for (int i = attackTowers.Count - 1; i >= 0; i--)
            {
                attackTowers.RemoveAt(i);
            }
    }

        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        public void spendPrestige(int points)
        {
            prestige -= points;
            String s = "Your Prestige: " + prestige;
            Vector2 temp = font.MeasureString(s);
            prestigePos.X = 640 - temp.X / 2;
        }
        public void applyArtifact(int index, int level)
        {
            if (index == 0)
            {
                if (level == 1)
                {
                    damageMultiplier = 1.1;
                    
                }
                if (level == 2)
                {
                    damageMultiplier = 1.2;

                }
                if (level == 3)
                {
                    applyCrowbar = true;
                }
            }
            if(index == 1) {
                if (level == 1)
                {
                    upgrade1Unlocked = true;
                    
                }
                if (level == 2)
                {
                    upgrade2Unlocked = true;
                   
                }
                if (level == 3)
                {
                    shouldRefundUpgrade = true;
                }
            }
            if (index == 2)
            {
                if (level == 1)
                {
                    healthDivider = .97;
                }
                if (level == 2)
                {
                    healthDivider = .93;
                }
                if (level == 3)
                {
                    healthDivider = .90;
                }
            }
            if (index == 3)
            {
                if (level == 1)
                {
                    breachedEnemiesAllowed = 1;
                }
                if (level == 2)
                {
                    breachedEnemiesAllowed = 2;
                }
                if (level == 3)
                {
                    lawnMowerAvaliable = true;
                }
            }
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                this.Exit();

             MouseState mouse = Mouse.GetState();
             KeyboardState kb = Keyboard.GetState();

            losCond.m = mouse;
            losCond.world = this;
            titleObj.mouse = mouse;
            titleObj.world = this;
            optObj.mouse = mouse;
            optObj.world = this;
            quitObj.mouse = mouse;
            quitObj.world = this;
            // Allows the game to exit
            time--;

            transistioner.Update();
            // TODO: Add your update logic here    

            if(transistion == transistionState.Transistioning) {
                transistioner.Update();
                if(transistioner.color.A >= 250 && transistioner.turnBlack) {
                    transistioner.turnBlack = false;
                    gS = transistioner.state;
                    transistioner.turnWhite = true;
                }
                if(transistioner.color.A <= 5 && transistioner.turnWhite) {
                    transistion = transistionState.Default;
                }
            }
            if(transistion == transistionState.Default) 
            {
                //Mikey
                if (gS == gameState.TitleScreen)
                {
                    titleObj.Update();
                }

                if (gS == gameState.Options)
                {
                    optObj.Update();
                }
                if (gS == gameState.QuitGame)
                {
                    quitObj.Update();
                }
                if ((gS == gameState.TitleScreen || gS == gameState.Options || gS == gameState.QuitGame || gS == gameState.ReallyQuit) && time == 0)
                {
                    titleTips.changeTip();
                    if (time == 0)
                        time = 360;

                }

                if (gS == gameState.Artifacts)
                {
                    artifactButtons[0].isOverChoice(mouse.X, mouse.Y, mouse, oldM);
                    artifactButtons[0].whatButton();
                    if (artifactButtons[0].bp == Button.buttonPress.pressed)
                    {
                        transistioner.state = gameState.PlayGame;
                        transistioner.turnBlack = true;
                        transistion = transistionState.Transistioning;
                    }
                    for (int i = 0; i < artifacts.Count; i++)
                    {
                        artifacts[i].isClicking(mouse);
                    }
                }


                if (gS == gameState.PlayGame)
                {
                    enemyTimer--;
                    if (activeEnemies.Count == 0 && waveButton.current == WaveButton.Selected.Disabled && enemies.Count == 0) {
                        waveButton.current = WaveButton.Selected.Default;
                    }

                    if (enemyTimer <= 0 && enemies.Count != 0)
                    {
                        loadEnemy();
                        enemyTimer = levelLoad.spawnT[currentWave-2];
                    }

                    for (int i = 0; i < activeEnemies.Count; i++)
                    {
                        activeEnemies[i].Update();
                        activeEnemies[i].pathing();
                        if (activeEnemies[i].markForDeletion) {
                            bar.updateResources(0, activeEnemies[i].goldWorth);
                            activeEnemies.Remove(activeEnemies[i]);
                        }
                    }
                }

                if (gS == gameState.LostGame)
                {
                    losCond.Update();
                    if (losCond.color.A < 250)
                    {
                        losCond.raiseColor();
                    }
                    else
                    {
                        for (int i = 0; i < losCond.lossButtons.Count(); i++)
                        {
                            if (losCond.lossButtons[i].col.A < 250)
                                losCond.lossButtons[i].raiseColor();
                        }
                    }
                    
                }


                //Vivek

                if (gS == gameState.PlayGame)
                {

                    for (int i = 0; i < attackTowers.Count; i++)
                    {
                        attackTowers[i].Update();
                        attackTowers[i].isBeingClicked(mouse);

                    }
                    for (int i = 0; i < resourceTowers.Count; i++)
                    {

                        if (waveButton.current == WaveButton.Selected.Disabled) {

                            resourceTowers[i].UpdateResources();
                            resourceTowers[i].Update();
                        }

                    }

                    if (waveButton.current != WaveButton.Selected.Disabled)
                    {
                        waveButton.isOverChoice(mouse.X, mouse.Y, mouse);
                    }
                    if (waveButton.current == WaveButton.Selected.Pressed)
                    {
                        loadNextWave(currentWave);
                        Console.WriteLine(currentWave);
                        currentWave++;
                        waveButton.current = WaveButton.Selected.Disabled;
                    }
                    mainBar.isClicking(mouse, kb);
                    Rectangle r = new Rectangle(mouse.X, mouse.Y, 1, 1);



                    Vector2 b = new Vector2(mouse.X, mouse.Y);





                    for (int i = 0; i < tileMap.GetLength(0); i++) {
                        for (int j = 0; j < tileMap.GetLength(1); j++) {
                            tileMap[i, j].isBeingHovered(mouse);
                        }
                    }
                    if (spawner != null)
                    {
                        spawner.Update(mouse);
                    }
                    Console.WriteLine(breachedEnemiesAllowed);
                    for (int i = 0; i < activeEnemies.Count; i++)
                    {
                        if (activeEnemies[i].pixelsMoved >= 250)
                        {
                            if (lawnMowerAvaliable)
                            {
                                Order66();
                                lawnMowerAvaliable = false;
                                break;
                            }
                            else if (breachedEnemiesAllowed > 0)
                            {
                                if (breachedEnemiesAllowed == 1)
                                {
                                    activeEnemies[i].health = 0;
                                    breachedEnemiesAllowed--;
                                    break;
                                }
                                if (breachedEnemiesAllowed == 2)
                                {
                                    activeEnemies[i].health = 0;
                                    breachedEnemiesAllowed--;
                                    break;
                                }
                            }
                            else
                                gS = gameState.LostGame;
                        }
                    }

                }

                if (gS == gameState.TitleScreen || gS == gameState.Options || gS == gameState.QuitGame || gS == gameState.ReallyQuit)
                {
                    bGtime++;

                    //bird boiz
                    if (birds.rec.X >= graphics.GraphicsDevice.Viewport.Width)
                    {
                        birds.rec.X = -graphics.GraphicsDevice.Viewport.Width / 4;
                        birds.rec.Y = rand.Next(-100, 100);
                    }
                    else
                        birds.rec.X++;
                    //cloud men
                    if (bGtime % 3 == 0)
                    {
                        cloud.rec.X--;
                        bGcloud.rec.X--;
                    }
                    if (cloud.rec.X == 0)
                        bGcloud.rec.X = cloud.rec.Width;
                    else if (bGcloud.rec.X == 0)
                        cloud.rec.X = bGcloud.rec.Width;

                    //background movement time
                    if (bGtime == 0)
                        bG.tex = bGt[0];
                    else if (bGtime == 8)
                        bG.tex = bGt[1];
                    else if (bGtime == 16)
                        bG.tex = bGt[2];
                    else if (bGtime == 24)
                        bG.tex = bGt[3];
                    else if (bGtime == 32)
                        bG.tex = bGt[4];
                    else if (bGtime == 40)
                        bG.tex = bGt[5];
                    else if (bGtime == 48)
                        bG.tex = bGt[6];
                    else if (bGtime == 56)
                        bG.tex = bGt[7];
                    else if (bGtime == 64)
                    {
                        bGtime = 0;
                        bG.tex = bGt[0];
                    }

                }

                if (gS == gameState.PlayGame)
                {
                    pauseButton[0].isOverChoice(mouse.X, mouse.Y, mouse, oldM);
                    pauseButton[0].whatButton();
                    if (pauseButton[0].bp == PauseButton.buttonPress.pressed && cooldown == false)
                    {
                        cooldown = true;
                        gS = gameState.Pause;
                        Console.WriteLine(gS);
                    }
                }
                if (cooldown == true)
                {
                    cdTime++;
                    if (cdTime >= 10)
                    {
                        cdTime = 0;
                        cooldown = false;
                    }

                }
                if (gS == gameState.Pause)
                {
                    pauseButton[1].isOverChoice(mouse.X, mouse.Y, mouse, oldM);
                    pauseButton[1].whatButton();
                    if (pauseButton[1].bp == PauseButton.buttonPress.pressed && cooldown == false)
                    {
                        cooldown = true;
                        gS = gameState.PlayGame;
                        Console.WriteLine(gS);
                    }
                }

                oldM = mouse;
        }
            base.Update(gameTime);
        }
        public void loadNextWave(int wave) {
            if(wave >= levelLoad.enemiesPerWave.Count) {
                return;
                //Win condition?
            }


            for (int i = 0; i < levelLoad.enemiesPerWave[wave]; i++ ) {
                EnemySuper e = totalEnemies[0];
                e.setHealth();
                enemies.Add(e);
                enemyTimer = 30;
                totalEnemies.Remove(e);
                
            }
        }

        public void Order66()
        {
            for (int i = activeEnemies.Count - 1; i >= 0; i--)
            {
                activeEnemies[i].health = 0;
            }
        }
        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.PeachPuff);
             
            spriteBatch.Begin(SpriteSortMode.Immediate, BlendState.NonPremultiplied);

            if (gS == gameState.TitleScreen || gS == gameState.Options || gS == gameState.QuitGame || gS == gameState.ReallyQuit)
            {
                //paulo
                cloud.Draw(gameTime, spriteBatch);
                bGcloud.Draw(gameTime, spriteBatch);
                bG.Draw(gameTime, spriteBatch);
                birds.Draw(gameTime, spriteBatch);
                titleTips.Draw(gameTime, spriteBatch);
            }

            //Mikey
            if (gS == gameState.TitleScreen)
            {
                titleObj.Draw(gameTime, spriteBatch);
            }
            if (gS == gameState.Options)
            {
                optObj.Draw(gameTime, spriteBatch);
            }
            if (gS == gameState.QuitGame)
            {
                quitObj.Draw(gameTime, spriteBatch);
            }

            if (gS == gameState.Artifacts)
            {
                spriteBatch.Draw(dummyTexture, artifactRectangle, Color.DarkSalmon);
                artifactButtons[0].Draw(gameTime, spriteBatch);
                for (int i = 0; i < artifacts.Count; i++)
                {
                    artifacts[i].Draw(gameTime, spriteBatch);

                }
                spriteBatch.Draw(artifactTitle, artTitlePos, Color.White);
                spriteBatch.DrawString(font, "Your Prestige: " + prestige, prestigePos, Color.LightGray);
            }



            if (gS == gameState.LostGame)
            {
                spriteBatch.Draw(this.Content.Load<Texture2D>("Conditions/LossImage"), new Rectangle(0, 0, graphics.GraphicsDevice.Viewport.Width, graphics.GraphicsDevice.Viewport.Height), Color.White);
                    losCond.Draw(gameTime, spriteBatch);
                

            }

            //Vivek

            if (gS == gameState.PlayGame || gS == gameState.Pause)
            {
                for (int i = 0; i < tileMap.GetLength(0); i++)
                {
                    for (int j = 0; j < tileMap.GetLength(1); j++)
                    {
                        tileMap[i, j].Draw(gameTime, spriteBatch);

                    }
                }

                for (int i = 0; i < attackTowers.Count; i++) {
                    attackTowers[i].Draw(gameTime, spriteBatch);
                }
                for (int i = 0; i < resourceTowers.Count; i++)
                {
                    resourceTowers[i].Draw(gameTime, spriteBatch);
                }

                for (int i = 0; i < activeEnemies.Count; i++)
                {
                    activeEnemies[i].Draw(gameTime, spriteBatch);
                }
                
                spriteBatch.DrawString(font, "" + (currentWave-1), new Vector2(1180, 140), Color.White);
                waveButton.Draw(gameTime, spriteBatch);
                bar.Draw(gameTime, spriteBatch);
                mainBar.Draw(gameTime, spriteBatch);
                if(spawner != null)
                {
                    spawner.Draw(gameTime, spriteBatch);
                }
                if(shownInfoBox != null) {
                    shownInfoBox.Draw(gameTime, spriteBatch);
                }
                if(shownUpgrade != null) {
                    shownUpgrade.Draw(gameTime, spriteBatch);
                   
                }
                if (gS == gameState.PlayGame)
                {
                    pauseButton[0].Draw(gameTime, spriteBatch);
                }
                else if (gS == gameState.Pause)
                {
                    spriteBatch.Draw(dummyTexture, new Rectangle(0, 0, graphics.GraphicsDevice.Viewport.Width, graphics.GraphicsDevice.Viewport.Height), new Color(0, 0, 0, 100));
                    pauseButton[1].Draw(gameTime, spriteBatch);
                    pauseinfobox.Draw(gameTime, spriteBatch);
                }

                
            }
            transistioner.Draw(gameTime, spriteBatch);

            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
