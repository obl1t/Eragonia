﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.IO;

namespace Eragonia_Demo_Day_One
{
    public class EnemySuper
    {
        public Texture2D spriteSheet;
        public Texture2D healthSprite;
        public List<Rectangle> sources = new List<Rectangle>();
        public Rectangle position;
        public Texture2D dummyTexture;
        public List<int> animationOrder = new List<int>();
        public int currentIndex = 0;
        public Color color;
        public Color healthColor = Color.Green;
        public Vector2 origin;
        public int enemyStartIndex;
        public int otherTimer = 0;
        public int speed;
        public double health = 10.0;
        public double totalHealth = 10;
        public int goldWorth = 0;
        public int prestigeWorth = 1;
        public Boolean markForDeletion = false;
        public Boolean showHealth = false;
        public Rectangle hitbox;
        public int rotation = 0;
        public Shockwave wave;
        public Boolean isBurning;
        public int burningTimer = 0;
        public int damageOverTime;
        public int maxBurn;
        public const int FRAMES_PER_FRAME = 5;
        int timer = 0;
        public Game1 world;
        public Rectangle healthBar;
        public double pixelsMoved;
        public Boolean isFirstHit = true;
        public Texture2D fireIcon;
        public Rectangle firePosition;
        public EnemySuper()
        {

        }

        public void setHealth()
        {
            health *= world.healthDivider;
        }

        public void setAttack()
        {
            currentIndex = enemyStartIndex;
            timer = enemyStartIndex * 10;
        }

        public virtual void incurDamage(int points, int towerType)
        {
            
            if (isFirstHit && world.applyCrowbar)
            {
                isFirstHit = false;
                firePosition = new Rectangle(position.X + 10, position.Y + 10, 24, 24);
                health -= 10;
            }
            else if(isFirstHit) {
                firePosition = new Rectangle(position.X + 10, position.Y + 10, 24, 24);
                isFirstHit = false;
            }
            showHealth = true;
            healthBar.Width = (int) (((double) health / (double) totalHealth) * position.Width) + 1;
            
            int x = (int) ((double)health / totalHealth * 255);
           
            healthColor.G = (byte) x;
            healthColor.R = (byte) (255 - x);

        }
        public void addAnimationOrder(int[] order)
        {
            for (int i = 0; i < order.Length; i++)
            {
                animationOrder.Add(order[i] - 1);
            }
        }

        public void calculateOrigin()
        {
            Rectangle a = sources[0];
           // a.Height -= 150;
            origin = new Vector2(a.Width / 2, a.Height / 2);
            //hitbox = new Rectangle(0, 0, 999, 999);
            hitbox = new Rectangle(position.X - 15, position.Y - 15 , 30, 30);
        }

        public virtual void Update()
        {

            timer++;
            firePosition.X = position.X + 10;
            firePosition.Y = position.Y + 10;
            if (timer % FRAMES_PER_FRAME == 0)
            {
                currentIndex++;
                if (currentIndex >= animationOrder.Count)
                {
                    currentIndex = 0;
                }
            }
            if(isBurning && timer % 10 == 0) {
                incurDamage(damageOverTime, 3);
            }
            if(isBurning) {
                burningTimer++;
                if(burningTimer >= maxBurn) {
                    burningTimer = 0;
                    isBurning = false;
                    damageOverTime = 0;
                }
            }
            if(health <= 0) {
                markForDeletion = true;
                position.X = -500;
                world.prestige += 1 * world.prestigeMult;
            }


            healthColor.A = 240;

            healthBar.X = position.X - 30;
            healthBar.Y = position.Y - 30;
        }

        public void upStep()
        {
            rotation = 0;
            position.Y -= speed;
            hitbox.Y -= speed;
        }
        public void downStep()
        {
            rotation = 180;
            position.Y += speed;
            hitbox.Y += speed;
        }
        public void leftStep()
        {
            rotation = 270;
            position.X -= speed;
            hitbox.X -= speed;
        }
        public void rightStep()
        {
            rotation = 90;
            position.X += speed;
            hitbox.X += speed;
        }

        public virtual void pathing()
        {
            otherTimer++;
            pixelsMoved += (double) (speed / 2.0);
            if (otherTimer % 2 == 0)
            {

                if (pixelsMoved <= 160)
                {
                    rightStep();
                }
                else if (pixelsMoved < 352)
                {
                    upStep();
                }
                else if (pixelsMoved < 608)
                {
                    rightStep();
                }
                else if (pixelsMoved < 992)
                {
                    downStep();
                }
                else if (pixelsMoved < 1184)
                {
                    rightStep();
                }
                else if (pixelsMoved < 1376)
                {
                    upStep();
                }
                else if (pixelsMoved < 1504)
                {
                    rightStep();
                }
                else if (pixelsMoved < 1632)
                {
                    upStep();
                }
                else if (pixelsMoved < 2016)
                {
                    rightStep();
                }
                else if (pixelsMoved < 2144)
                {
                    downStep();
                }
                else if (pixelsMoved < 2336)
                {
                    rightStep();
                }
            }

        }


        public virtual void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(spriteSheet, new Rectangle(position.X + 3, position.Y + 3, position.Width, position.Height), sources[animationOrder[currentIndex]],
            new Color(0, 0, 0, 120), MathHelper.ToRadians(rotation), origin, SpriteEffects.None, 0.0f);
            spriteBatch.Draw(spriteSheet, position, sources[animationOrder[currentIndex]], color, MathHelper.ToRadians(rotation), origin, SpriteEffects.None, 0.0f);
            if(showHealth)
                spriteBatch.Draw(healthSprite, healthBar, new Rectangle(0, 0, 1152, 648), healthColor);
            if (isBurning)
                spriteBatch.Draw(fireIcon, firePosition, Color.White);
            //spriteBatch.Draw(dummyTexture, hitbox, Color.White);
        }
    }
}

