﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.IO;

namespace Eragonia_Demo_Day_One
{
    public class WaveLoader : Microsoft.Xna.Framework.Game
    {
        public Game1 world;
        public List<int> spawnT = new List<int>();
    

        public WaveLoader()
        {
            enemiesPerWave.Add(0);
        }
        public List<int> enemiesPerWave = new List<int>();

        public void loadEnemies(String fileName, List<EnemySuper> enemi)
        {
            using (StreamReader reader = new StreamReader(fileName))
            {
                try
                {
                    int i = 0;
                    while (!reader.EndOfStream)
                    {
                        String[] temp = reader.ReadLine().Split(' ');
                        String s = temp[0];
                        Char[] chars = s.ToCharArray();
                        enemiesPerWave.Add(chars.Length);
                        
                        for (int j = 0; j < chars.Length; j++)
                        {
                           
                            if (chars[j] == 'm')
                            {
                                Measeling enemy = new Measeling();
                                enemy.rotation = 90;
                                enemy.spriteSheet = world.Content.Load<Texture2D>("Enemy/Measeling");
                                enemy.fireIcon = world.Content.Load<Texture2D>("Enemy/GUI/fireIcon");
                                enemy.position = new Rectangle(0, 480, 64, 64);
                                enemy.world = world;
                                enemi.Add(enemy);
                                
                            }
                            else if (chars[j] == 'i')
                            {
                                Mire enemy = new Mire();
                                enemy.rotation = 90;
                                enemy.spriteSheet = world.Content.Load<Texture2D>("Enemy/Mire");
                                enemy.fireIcon = world.Content.Load<Texture2D>("Enemy/GUI/fireIcon");
                                enemy.position = new Rectangle(0, 480, 64, 64);
                                enemy.world = world;
                                enemi.Add(enemy);
                            }
                            else if (chars[j] == 'a')
                            {
                                Mammoth enemy = new Mammoth();
                                enemy.rotation = 90;
                                enemy.spriteSheet = world.Content.Load<Texture2D>("Enemy/Mammoth");
                                enemy.fireIcon = world.Content.Load<Texture2D>("Enemy/GUI/fireIcon");
                                enemy.position = new Rectangle(0, 480, 64, 64);
                                enemy.world = world;
                                enemi.Add(enemy);
                            }
                            else if (chars[j] == 'g')
                            {
                                Magnapinna enemy = new Magnapinna();
                                enemy.rotation = 90;
                                enemy.spriteSheet = world.Content.Load<Texture2D>("Enemy/Magnapinna");
                                enemy.fireIcon = world.Content.Load<Texture2D>("Enemy/GUI/fireIcon");
                                enemy.position = new Rectangle(0, 480, 64, 64);
                                enemy.world = world;
                                enemi.Add(enemy);
                            }
                            else if (chars[j] == 'c')
                            {
                                Mace enemy = new Mace();
                                enemy.rotation = 90;
                                enemy.spriteSheet = world.Content.Load<Texture2D>("Enemy/Mace");
                                enemy.passiveTexture = world.Content.Load<Texture2D>("Enemy/MaceS");
                                enemy.fireIcon = world.Content.Load<Texture2D>("Enemy/GUI/fireIcon");
                                enemy.position = new Rectangle(0, 480, 64, 64);
                                enemy.world = world;
                                enemy.loader = this;
                                enemi.Add(enemy);
                                
                                
                            }
                            i++;
                        }
                        spawnT.Add(Int32.Parse(temp[1]));
                    }
                    
                }
                catch
                {
                    Console.WriteLine("Ay yo this shit broken");
                }
            }
        }
        public void spawnMiniling(int xPos, int yPos, double pixMoved)
        {
            Miniling enemy = new Miniling();
            enemy.rotation = 90;
            enemy.spriteSheet = world.Content.Load<Texture2D>("Enemy/Miniling");
            enemy.pixelsMoved = pixMoved;
            enemy.position = new Rectangle(xPos, yPos, 64, 64);
            enemy.calculateOrigin();
            enemy.fireIcon = world.Content.Load<Texture2D>("Enemy/GUI/fireIcon");
            enemy.healthSprite = world.Content.Load<Texture2D>("Enemy/EnemyHealthBar");
            enemy.healthBar = new Rectangle(enemy.position.X, enemy.position.Y, enemy.position.Width, 10);
            enemy.dummyTexture = world.dummyTexture;
            enemy.world = world;
            world.activeEnemies.Add(enemy);
        }
    }
}
